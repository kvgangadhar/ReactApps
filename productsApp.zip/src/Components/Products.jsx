import React, { Component } from 'react';
import axios from 'axios';
import { Input, FormGroup, Label, Modal, ModalHeader, ModalBody, ModalFooter, Table, Button } from 'reactstrap';

class Products extends Component {

  state = {
    products: [],
    newproductData: {
      id: '',
      Name: '',
      Description: '',
      price: ''
    },
    editproductData: {
      id: '',
      Name: ''
    },
    newproductModal: false,
    editproductModal: false
  }
  componentWillMount() {
    this._refreshproducts();
  }
  toggleNewproductModal() {
    this.setState({
      newproductModal: !this.state.newproductModal
    });
  }
  toggleEditproductModal() {
    this.setState({
      editproductModal: !this.state.editproductModal
    });
  }
  addproduct() {
    axios.post('products', this.state.newproductData).then((response) => {
      let { products } = this.state;
      products.push(response.data);
      this.setState({
        products, newproductModal: false, newproductData: {
          id: '',
          Name: '',
          Description: '',
          price: ''
        }
      });
    });
  }
  updateproduct() {
    let { id, Name, Description, price } = this.state.editproductData;

    axios.put('products/' + this.state.editproductData.id, {
      id, Name, Description, price
    }).then((response) => {
      this._refreshproducts();
      this.setState({
        editproductModal: false, editproductData: { id: '', Name: '', Description: '', price: '' }
      })
    });
  }
  editproduct(id, Name, Description, price) {
    this.setState({
      editproductData: { id, Name, Description, price }, editproductModal: !this.state.editproductModal
    });
  }
  deleteproduct(id) {
    axios.delete('products/' + id).then((response) => {
      this._refreshproducts();
    });
  }
  _refreshproducts() {
    axios.get('products').then((response) => {
      this.setState({
        products: response.data
      })
    });
  }
  render() {
    let products = this.state.products.map((product) => {
      return (
        <tr key={product.id}>
          <td>{product.id}</td>
          <td>{product.Name}</td>
          <td>{product.Description}</td>
          <td>{product.price}</td>
          <td>
            <Button color="success" size="sm" className="mr-2" onClick={this.editproduct.bind(this, product.id, product.Name, product.Description, product.price)}>Edit</Button>
            <Button color="danger" size="sm" onClick={this.deleteproduct.bind(this, product.id)}>Delete</Button>
          </td>
        </tr>
      )
    });
    return (
      <div className="App container">
        <Button className="my-3" color="primary" onClick={this.toggleNewproductModal.bind(this)}>Add product</Button>

        <Modal isOpen={this.state.newproductModal} toggle={this.toggleNewproductModal.bind(this)}>
          <ModalHeader toggle={this.toggleNewproductModal.bind(this)}>Add a new product</ModalHeader>
          <ModalBody>
            <FormGroup>
              <Label for="id">id</Label>
              <Input id="id" value={this.state.newproductData.id} onChange={(e) => {
                let { newproductData } = this.state;
                newproductData.id = e.target.value;
                this.setState({ newproductData });
              }} />
            </FormGroup>
            <FormGroup>
              <Label for="Name">Name</Label>
              <Input id="Name" value={this.state.newproductData.Name} onChange={(e) => {
                let { newproductData } = this.state;

                newproductData.Name = e.target.value;

                this.setState({ newproductData });
              }} />
            </FormGroup>
            <FormGroup>
              <Label for="Description">Description</Label>
              <Input id="Description" value={this.state.newproductData.Description} onChange={(e) => {
                let { newproductData } = this.state;

                newproductData.Description = e.target.value;

                this.setState({ newproductData });
              }} />
            </FormGroup>
            <FormGroup>
              <Label for="price">price</Label>
              <Input id="price" value={this.state.newproductData.price} onChange={(e) => {
                let { newproductData } = this.state;

                newproductData.price = e.target.value;

                this.setState({ newproductData });
              }} />
            </FormGroup>

          </ModalBody>
          <ModalFooter>
            <Button color="primary" onClick={this.addproduct.bind(this)}>Add product</Button>{' '}
            <Button color="secondary" onClick={this.toggleNewproductModal.bind(this)}>Cancel</Button>
          </ModalFooter>
        </Modal>

        <Modal isOpen={this.state.editproductModal} toggle={this.toggleEditproductModal.bind(this)}>
          <ModalHeader toggle={this.toggleEditproductModal.bind(this)}>Edit a new product</ModalHeader>
          <ModalBody>
            <FormGroup>
              <Label for="id">id</Label>
              <Input id="id" disabled="true" value={this.state.editproductData.id} onChange={(e) => {
                let { editproductData } = this.state;
                editproductData.id = e.target.value;
                this.setState({ editproductData });
              }} />
            </FormGroup>
            <FormGroup>
              <Label for="Name">Name</Label>
              <Input id="Name" value={this.state.editproductData.Name} onChange={(e) => {
                let { editproductData } = this.state;
                editproductData.Name = e.target.value;
                this.setState({ editproductData });
              }} />
            </FormGroup>
            <FormGroup>
              <Label for="Description">Description</Label>
              <Input id="Description" value={this.state.editproductData.Description} onChange={(e) => {
                let { editproductData } = this.state;
                editproductData.Description = e.target.value;
                this.setState({ editproductData });
              }} />
            </FormGroup>
            <FormGroup>
              <Label for="price">price</Label>
              <Input id="price" value={this.state.editproductData.price} onChange={(e) => {
                let { editproductData } = this.state;
                editproductData.price = e.target.value;
                this.setState({ editproductData });
              }} />
            </FormGroup>
          </ModalBody>
          <ModalFooter>
            <Button color="primary" onClick={this.updateproduct.bind(this)}>Update product</Button>{' '}
            <Button color="secondary" onClick={this.toggleEditproductModal.bind(this)}>Cancel</Button>
          </ModalFooter>
        </Modal>
        <Table>
          <thead>
            <tr>
              <th>id</th>
              <th>Name</th>
              <th>Description</th>
              <th>price</th>
              <th>Action</th>
            </tr>
          </thead>

          <tbody>
            {products}
          </tbody>
        </Table>
      </div>
    );
  }
}

export default Products;
