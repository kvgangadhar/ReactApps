import React, { Component } from "react";
import "./App.css";
import Products from "./Components/Products";
import 'bootstrap/dist/css/bootstrap.css';

class  App extends Component {
  render(){
  return (
    <React.Fragment>
    
      <Products/>
    </React.Fragment>
  );
}
}



export default App;
